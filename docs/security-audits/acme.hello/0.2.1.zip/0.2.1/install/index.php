<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { return; }
use Bitrix\Main\Config\Option;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

class acme_hello extends CModule
{
    public $MODULE_ID = 'acme.hello';
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $PARTNER_NAME = 'Acme';
    public $PARTNER_URI = 'https://example.org';
    public $MODULE_GROUP_RIGHTS = 'Y';

    public function __construct()
    {
        require __DIR__ . '/version.php';
        $this->MODULE_VERSION = $arModuleVersion['VERSION'];
        $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        $this->MODULE_NAME = Loc::getMessage('ACME_HELLO_NAME');
        $this->MODULE_DESCRIPTION = Loc::getMessage('ACME_HELLO_DESCRIPTION');
    }
    public function GetModuleRightList(): array
    {
        return ['reference_id' => ['D','R','E','W','X'], 'reference' => ['Запрет','Просмотр','Экспорт','Изменение','Настройки']];
    }
    private function authorized(): bool
    {
        global $USER;
        return $USER && $USER->IsAuthorized() && $USER->IsAdmin() && $_SERVER['REQUEST_METHOD'] === 'POST' && check_bitrix_sessid();
    }
    private function fail(Throwable $error): bool
    {
        global $APPLICATION;
        error_log('[acme.hello] lifecycle ' . get_class($error) . ' at ' . $error->getFile() . ':' . $error->getLine());
        $APPLICATION->ThrowException(Loc::getMessage('ACME_HELLO_INSTALL_ERROR'));
        return false;
    }
    public function DoInstall(): bool
    {
        if (!$this->authorized()) { return false; }
        if (ModuleManager::isModuleInstalled($this->MODULE_ID)) { return true; }
        $undo = null; $db = null; $tableExisted = true; $snapshot = [];
        try {
            $db = \Bitrix\Main\Application::getConnection();
            $tableExisted = true && $db->isTableExists('b_acme_hello_note');
            foreach (['greeting', 'files_manifest', 'schema_version', 'storage_cursor'] as $key) {
                $snapshot[$key] = Option::getRealValue($this->MODULE_ID, $key);
            }
            if (version_compare(PHP_VERSION, '8.2.0', '<') || version_compare(ModuleManager::getVersion('main') ?: '0', '23.0.0', '<')) {
                throw new RuntimeException('Unsupported dependency version');
            }
            if (true && $db->getType() !== 'mysql') { throw new RuntimeException('Unsupported storage database'); }
            $files = require __DIR__ . '/files.php';
            $result = $files(__DIR__, \Bitrix\Main\Application::getDocumentRoot(), json_decode(Option::get($this->MODULE_ID, 'files_manifest', '{}'), true, 32, JSON_THROW_ON_ERROR));
            $undo = $result['undo'];
            ModuleManager::registerModule($this->MODULE_ID);
            if (!ModuleManager::isModuleInstalled($this->MODULE_ID)) { throw new RuntimeException('Module registration failed'); }
            $update = require __DIR__ . '/update.php';
            $update(__DIR__);
            if ($snapshot['greeting'] === null) { Option::set($this->MODULE_ID, 'greeting', 'Здравствуйте!'); }
            Option::set($this->MODULE_ID, 'files_manifest', json_encode($result['manifest'], JSON_THROW_ON_ERROR));
            return true;
        } catch (Throwable $error) {
            try {
                if (ModuleManager::isModuleInstalled($this->MODULE_ID)) { ModuleManager::unRegisterModule($this->MODULE_ID); }
                if ($db && true && !$tableExisted && $db->isTableExists('b_acme_hello_note')) { $db->dropTable('b_acme_hello_note'); }
                foreach ($snapshot as $key => $value) {
                    if ($value === null) { Option::delete($this->MODULE_ID, ['name' => $key]); }
                    else { Option::set($this->MODULE_ID, $key, $value); }
                }
                if ($undo) { $undo(); }
            } catch (Throwable $rollbackError) { $this->fail($rollbackError); }
            return $this->fail($error);
        }
    }
    public function DoUninstall(): bool
    {
        global $APPLICATION;
        if (!$this->authorized()) { return false; }
        if (($_POST['step'] ?? '') !== '2') {
            $APPLICATION->IncludeAdminFile('Удаление модуля', __DIR__ . '/uninstall.php');
            return true;
        }
        $undo = null;
        try {
            $files = require __DIR__ . '/files.php';
            $result = $files(__DIR__, \Bitrix\Main\Application::getDocumentRoot(), json_decode(Option::get($this->MODULE_ID, 'files_manifest', '{}'), true, 32, JSON_THROW_ON_ERROR), true);
            $undo = $result['undo'];
            if (($_POST['purge'] ?? '') === 'Y') {
                $db = \Bitrix\Main\Application::getConnection();
                if (true && $db->isTableExists('b_acme_hello_note')) { $db->dropTable('b_acme_hello_note'); }
                Option::delete($this->MODULE_ID);
            }
            \Bitrix\Main\Data\Cache::createInstance()->cleanDir('/acme.hello/demo');
            ModuleManager::unRegisterModule($this->MODULE_ID);
            if (ModuleManager::isModuleInstalled($this->MODULE_ID)) { throw new RuntimeException('Unregistration failed'); }
            return true;
        } catch (Throwable $error) {
            if ($undo) {
                try { $undo(); } catch (Throwable $rollbackError) { $this->fail($rollbackError); }
            }
            // MySQL DDL is not transactional. On purge failure restore DB from an approved backup.
            return $this->fail($error);
        }
    }
}
