<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { return; }
if (!\Bitrix\Main\Loader::includeModule('acme.hello')) { return; }
use Acme\Hello\Access;
use Acme\Hello\Demo;
use Acme\Hello\Diagnostics;
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);
try {
    Access::requirePermission('settings');
    if ($_SERVER['REQUEST_METHOD'] === 'POST') { Demo::save($_POST['greeting'] ?? null); }
    $data = Demo::read();
} catch (\DomainException $error) { ShowError(Loc::getMessage('ACME_HELLO_DENIED')); return; }
catch (\Throwable $error) { Diagnostics::report($error); ShowError(Loc::getMessage('ACME_HELLO_FAILED')); return; }
?>
<form method="post">
    <?= bitrix_sessid_post() ?>
    <label for="acme_hello-greeting"><?= htmlspecialcharsbx(Loc::getMessage('ACME_HELLO_GREETING')) ?></label>
    <input id="acme_hello-greeting" name="greeting" maxlength="500" value="<?= htmlspecialcharsbx($data['text']) ?>">
    <button type="submit"><?= htmlspecialcharsbx(Loc::getMessage('ACME_HELLO_SAVE')) ?></button>
</form>
