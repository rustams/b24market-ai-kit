<?php
$MESS['ACME_HELLO_NAME'] = 'Приветствие';
$MESS['ACME_HELLO_DESCRIPTION'] = 'Защищённый пример';
$MESS['ACME_HELLO_INSTALL_ERROR'] = 'Операция остановлена. Подробности в защищённом серверном журнале.';
