<?php
$MESS['ACME_HELLO_DENIED'] = 'Доступ запрещён или запрос не подтверждён.';
$MESS['ACME_HELLO_FAILED'] = 'Операция не выполнена. Обратитесь к администратору.';
$MESS['ACME_HELLO_GREETING'] = 'Приветствие';
$MESS['ACME_HELLO_SAVE'] = 'Сохранить';
