<?php
// Append ordered, idempotent migrations; never change a released migration.
return [
    1 => static function (): void {
        if (true) {
            $db = \Bitrix\Main\Application::getConnection();
            if ($db->getType() !== 'mysql') { throw new RuntimeException('Optional storage supports MySQL only'); }
            if (!$db->isTableExists('b_acme_hello_note')) {
                $db->queryExecute('CREATE TABLE b_acme_hello_note (ID INT NOT NULL AUTO_INCREMENT, OWNER_ID INT NOT NULL, TEXT VARCHAR(500) NOT NULL, PRIMARY KEY(ID), INDEX IX_OWNER (OWNER_ID))');
                // Reset technical progress only when the corresponding storage did not exist.
                \Bitrix\Main\Config\Option::set('acme.hello', 'storage_cursor', '0');
            }
        }
    },
];
