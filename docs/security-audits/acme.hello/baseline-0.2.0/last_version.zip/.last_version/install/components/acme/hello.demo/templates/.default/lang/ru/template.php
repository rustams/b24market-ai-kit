<?php
$MESS['ACME_HELLO_FILTER'] = 'Представление';
$MESS['ACME_HELLO_WELCOME'] = 'Приветствие';
$MESS['ACME_HELLO_STATUS'] = 'Состояние';
$MESS['ACME_HELLO_SHOW'] = 'Показать';
