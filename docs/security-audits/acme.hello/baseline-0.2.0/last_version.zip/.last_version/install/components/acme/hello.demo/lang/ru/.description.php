<?php
$MESS['ACME_HELLO_COMPONENT_NAME'] = 'Защищённый пример';
$MESS['ACME_HELLO_COMPONENT_DESCRIPTION'] = 'Пример прав и эффективного фильтра';
