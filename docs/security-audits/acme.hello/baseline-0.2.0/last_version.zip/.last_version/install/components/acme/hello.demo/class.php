<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }

class acme_helloDemoComponent extends CBitrixComponent
{
    public function executeComponent()
    {
        if (!\Bitrix\Main\Loader::includeModule('acme.hello')) { ShowError('Модуль недоступен.'); return; }
        try {
            $this->arResult = \Acme\Hello\Demo::read($_GET['filter'] ?? null);
            $this->includeComponentTemplate();
        } catch (\DomainException $error) {
            ShowError('Доступ запрещён или некорректный запрос.');
        } catch (\Throwable $error) {
            $id = \Acme\Hello\Diagnostics::report($error);
            ShowError('Не удалось загрузить данные. Код обращения: ' . $id);
        }
    }
}
