<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) { die(); }
\Bitrix\Main\Localization\Loc::loadMessages(__FILE__);
?>
<form method="get">
    <label for="acme_hello-filter"><?= htmlspecialcharsbx(\Bitrix\Main\Localization\Loc::getMessage('ACME_HELLO_FILTER')) ?></label>
    <select id="acme_hello-filter" name="filter">
        <option value="welcome" <?= $arResult['filter'] === 'welcome' ? 'selected' : '' ?>><?= htmlspecialcharsbx(\Bitrix\Main\Localization\Loc::getMessage('ACME_HELLO_WELCOME')) ?></option>
        <option value="status" <?= $arResult['filter'] === 'status' ? 'selected' : '' ?>><?= htmlspecialcharsbx(\Bitrix\Main\Localization\Loc::getMessage('ACME_HELLO_STATUS')) ?></option>
    </select>
    <button type="submit"><?= htmlspecialcharsbx(\Bitrix\Main\Localization\Loc::getMessage('ACME_HELLO_SHOW')) ?></button>
</form>
<p><?= htmlspecialcharsbx($arResult['text']) ?></p>
